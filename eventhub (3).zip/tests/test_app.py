import os
import sys
from datetime import timedelta

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from app import create_app  # noqa: E402
from app.models import Event, Registration, User, db, now_local  # noqa: E402

TOKEN = "test-token"


@pytest.fixture()
def app(tmp_path):
    app = create_app({"TESTING": True, "SEED_DEMO": False, "SQLALCHEMY_DATABASE_URI": "sqlite:///" + str(tmp_path / "t.db")})
    yield app
    with app.app_context():
        db.session.remove()
        db.drop_all()


def client(app):
    c = app.test_client()
    with c.session_transaction() as s:
        s["_csrf"] = TOKEN
    return c


def post(c, url, **data):
    data["_csrf"] = TOKEN
    return c.post(url, data=data)


def signup(c, email, name="User One"):
    return post(c, "/register", name=name, email=email, password="password123", confirm="password123")


def dt(days=5, hours=0):
    return (now_local() + timedelta(days=days, hours=hours)).strftime("%Y-%m-%dT%H:%M")


def create_event(c, **over):
    data = dict(title="Python Workshop", description="Learn Flask", category="Technical", venue="Lab 1",
                starts_at=dt(5), ends_at=dt(5, 3), capacity="2", price="0")
    data.update(over)
    r = post(c, "/events/new", **data)
    return r


def first_event_id(app):
    with app.app_context():
        return Event.query.order_by(Event.id).first().id


def setup_two(app):
    org, a = client(app), client(app)
    signup(org, "org@example.com", "Organizer")
    signup(a, "a@example.com", "Alice")
    create_event(org)
    return org, a, first_event_id(app)


# ---------- auth ----------
def test_signup_login_logout_and_validation(app):
    c = client(app)
    assert post(c, "/register", name="A", email="bad", password="x", confirm="y").status_code == 400
    assert signup(c, "a@example.com").status_code == 302
    assert signup(client(app), "a@example.com").status_code == 400  # duplicate
    post(c, "/logout")
    assert post(c, "/login", email="a@example.com", password="wrong").status_code == 401
    assert post(c, "/login", email="a@example.com", password="password123").status_code == 302


def test_csrf_enforced_and_open_redirect_blocked(app):
    assert app.test_client().post("/login", data={"email": "x", "password": "y"}).status_code == 400
    c = client(app)
    signup(c, "a@example.com")
    post(c, "/logout")
    r = c.post("/login?next=//evil.com", data={"email": "a@example.com", "password": "password123", "_csrf": TOKEN})
    assert "evil.com" not in r.headers["Location"]


# ---------- events ----------
def test_public_browse_and_detail(app):
    org, _, eid = setup_two(app)
    anon = app.test_client()
    page = anon.get("/").get_data(as_text=True)
    assert "Python Workshop" in page
    assert anon.get(f"/events/{eid}").status_code == 200
    assert anon.get("/events/9999").status_code == 404
    assert b"Log in to register" in anon.get(f"/events/{eid}").data


def test_event_validation(app):
    c = client(app)
    signup(c, "o@example.com")
    assert create_event(c, title="ab").status_code == 400
    assert create_event(c, capacity="0").status_code == 400
    assert create_event(c, category="Nope").status_code == 400
    assert create_event(c, starts_at=dt(-2)).status_code == 400  # past
    assert create_event(c, ends_at=dt(4)).status_code == 400  # ends before start
    assert create_event(c, price="-5").status_code == 400
    assert create_event(c).status_code == 302


def test_only_owner_can_manage(app):
    org, other, eid = setup_two(app)
    for url in (f"/events/{eid}/edit", f"/events/{eid}/delete", f"/events/{eid}/cancel", f"/events/{eid}/attendees"):
        assert other.get(url).status_code == 403
    assert post(other, f"/events/{eid}/delete").status_code == 403
    assert org.get(f"/events/{eid}/attendees").status_code == 200
    assert app.test_client().get(f"/events/{eid}/edit").status_code == 302  # login redirect


def test_edit_event_and_capacity_rule(app):
    org, a, eid = setup_two(app)
    post(a, f"/events/{eid}/register")
    r = post(org, f"/events/{eid}/edit", title="Renamed", description="", category="Technical", venue="Lab 2",
             starts_at=dt(6), ends_at="", capacity="1", price="50")
    assert r.status_code == 302
    r = post(org, f"/events/{eid}/edit", title="Renamed", description="", category="Technical", venue="Lab 2",
             starts_at=dt(6), ends_at="", capacity="0", price="50")
    assert r.status_code == 400


# ---------- registration + waitlist ----------
def test_register_waitlist_and_promotion(app):
    org, a, eid = setup_two(app)  # capacity 2
    b, c = client(app), client(app)
    signup(b, "b@example.com", "Bob")
    signup(c, "c@example.com", "Cara")

    assert post(a, f"/events/{eid}/register").status_code == 302
    post(b, f"/events/{eid}/register")
    post(c, f"/events/{eid}/register")  # full -> waitlist

    with app.app_context():
        regs = {r.user.name: r for r in Registration.query.all()}
        assert regs["Alice"].status == "confirmed" and regs["Bob"].status == "confirmed"
        assert regs["Cara"].status == "waitlisted"
        assert len({r.ticket_code for r in regs.values()}) == 3

    assert b"#1" in c.get(f"/events/{eid}").data  # waitlist position

    post(a, f"/events/{eid}/unregister")  # Alice leaves -> Cara promoted
    with app.app_context():
        regs = {r.user.name: r for r in Registration.query.all()}
        assert regs["Alice"].status == "cancelled" and regs["Cara"].status == "confirmed"


def test_double_registration_blocked_and_reregister(app):
    _, a, eid = setup_two(app)
    post(a, f"/events/{eid}/register")
    r = a.post(f"/events/{eid}/register", data={"_csrf": TOKEN}, follow_redirects=True)
    assert b"already registered" in r.data
    post(a, f"/events/{eid}/unregister")
    post(a, f"/events/{eid}/register")
    with app.app_context():
        assert Registration.query.count() == 1
        assert Registration.query.first().status == "confirmed"


def test_cannot_register_for_cancelled_or_past_events(app):
    org, a, eid = setup_two(app)
    post(org, f"/events/{eid}/cancel")
    r = a.post(f"/events/{eid}/register", data={"_csrf": TOKEN}, follow_redirects=True)
    assert b"closed" in r.data
    with app.app_context():
        user = User.query.filter_by(email="org@example.com").first()
        past = Event(organizer_id=user.id, title="Old", venue="x", category="Other", capacity=5,
                     starts_at=now_local() - timedelta(days=3))
        db.session.add(past)
        db.session.commit()
        pid = past.id
    r = a.post(f"/events/{pid}/register", data={"_csrf": TOKEN}, follow_redirects=True)
    assert b"closed" in r.data


def test_capacity_increase_promotes_waitlist(app):
    org, a, eid = setup_two(app)
    others = []
    for i in range(3):
        c = client(app)
        signup(c, f"u{i}@example.com", f"U{i}")
        post(c, f"/events/{eid}/register")
        others.append(c)
    with app.app_context():
        assert Registration.query.filter_by(status="waitlisted").count() == 1
    post(org, f"/events/{eid}/edit", title="Python Workshop", description="", category="Technical", venue="Lab 1",
         starts_at=dt(5), ends_at="", capacity="5", price="0")
    with app.app_context():
        assert Registration.query.filter_by(status="waitlisted").count() == 0


# ---------- organizer tools ----------
def test_attendees_checkin_and_csv(app):
    org, a, eid = setup_two(app)
    a2 = client(app)
    signup(a2, "evil@example.com", "=HYPERLINK(1)")
    post(a, f"/events/{eid}/register")
    post(a2, f"/events/{eid}/register")
    page = org.get(f"/events/{eid}/attendees").get_data(as_text=True)
    assert "Alice" in page and "a@example.com" in page
    with app.app_context():
        rid = Registration.query.filter_by(user_id=User.query.filter_by(email="a@example.com").first().id).first().id
    assert post(org, f"/events/{eid}/attendees/{rid}/checkin").status_code == 302
    with app.app_context():
        assert db.session.get(Registration, rid).checked_in is True
    assert post(a, f"/events/{eid}/attendees/{rid}/checkin").status_code == 403  # not organizer
    csv_text = org.get(f"/events/{eid}/attendees.csv").get_data(as_text=True)
    assert "ticket_code" in csv_text and "'=HYPERLINK" in csv_text


def test_my_tickets_and_my_events(app):
    org, a, eid = setup_two(app)
    post(a, f"/events/{eid}/register")
    assert b"Python Workshop" in a.get("/my/tickets").data
    page = org.get("/my/events").get_data(as_text=True)
    assert "Organizer dashboard" in page and "1/2" in page
    assert post(org, f"/events/{eid}/delete").status_code == 302
    with app.app_context():
        assert Registration.query.count() == 0 and Event.query.count() == 0


def test_filters_pagination_and_api(app):
    c = client(app)
    signup(c, "o@example.com")
    for i in range(11):
        create_event(c, title=f"Event {i:02d}", category="Technical" if i % 2 else "Sports",
                     price="0" if i % 2 else "100")
    assert b"Page 1 of 2" in c.get("/").data
    assert b"Event 01" in c.get("/?category=Technical&free=1").data
    assert b"Event 00" not in c.get("/?category=Technical").data
    assert b"Event 03" in c.get("/?q=event 03").data
    data = c.get("/api/events").json
    assert len(data) == 11 and data[0]["seats_left"] == 2
    assert c.get("/api/events/1").json["capacity"] == 2
    assert c.get("/api/events/999").status_code == 404
    assert c.get("/api/health").json["status"] == "ok"


def test_xss_escaped(app):
    c = client(app)
    signup(c, "o@example.com")
    create_event(c, title="<script>alert(1)</script>")
    assert b"<script>alert(1)</script>" not in c.get("/").data
    assert b"&lt;script&gt;" in c.get("/").data


def test_events_are_preloaded_by_default(tmp_path, monkeypatch):
    monkeypatch.delenv("SEED_DEMO", raising=False)
    fresh = create_app({"SQLALCHEMY_DATABASE_URI": "sqlite:///" + str(tmp_path / "d.db")})
    page = fresh.test_client().get("/").get_data(as_text=True)
    assert "AWS Cloud Workshop" in page and "Inter-College Hackathon" in page
    with fresh.app_context():
        assert Event.query.count() == 6
    again = create_app({"SQLALCHEMY_DATABASE_URI": "sqlite:///" + str(tmp_path / "d.db")})  # restart: no duplicates
    with again.app_context():
        assert Event.query.count() == 6


def test_seed_can_be_disabled(tmp_path, monkeypatch):
    monkeypatch.setenv("SEED_DEMO", "0")
    off = create_app({"SQLALCHEMY_DATABASE_URI": "sqlite:///" + str(tmp_path / "o.db")})
    with off.app_context():
        assert Event.query.count() == 0


def test_seed_runs_even_if_users_exist(tmp_path):
    uri = "sqlite:///" + str(tmp_path / "s2.db")
    first = create_app({"TESTING": True, "SEED_DEMO": False, "SQLALCHEMY_DATABASE_URI": uri})
    with first.app_context():
        u = User(name="Existing", email="existing@example.com")
        u.set_password("password123")
        db.session.add(u)
        db.session.commit()
    second = create_app({"TESTING": True, "SEED_DEMO": True, "SQLALCHEMY_DATABASE_URI": uri})
    with second.app_context():
        assert Event.query.count() == 6 and User.query.count() == 2
